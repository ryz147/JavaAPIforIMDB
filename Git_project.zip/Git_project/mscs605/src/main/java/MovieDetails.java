import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/MovieDetails")
public class MovieDetails extends HttpServlet {
    RequestDispatcher rd;
    public MovieDetails(){
        super();
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id =request.getParameter("name");
        HashMap result = null;
        try {

            result = getFilmDetails(id);
        } catch (Exception e) {
            e.printStackTrace();
        }


        request.setAttribute("moviesList", result);

        rd = request.getRequestDispatcher("DetailPage.jsp");
        rd.forward(request,response);

    }

    public static HashMap getFilmDetails(String id) throws Exception, IOException {
        String apikey = "e2f0126d33msh1bcc2d0fef09a0fp1e5165jsn03a911a71e43";
        HttpResponse<String> response = Unirest.get("https://imdb-internet-movie-database-unofficial.p.rapidapi.com/film/"+id)
                .header("x-rapidapi-host", "imdb-internet-movie-database-unofficial.p.rapidapi.com")
                .header("x-rapidapi-key", apikey)
                .asString();
        String res = response.getBody();
        HashMap<String, List<Map>> result =new ObjectMapper().readValue(res,HashMap.class);
        return result;
    }
}
