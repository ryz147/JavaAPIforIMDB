import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;

import com.mashape.unirest.http.exceptions.UnirestException;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class APIUtil {

    public static String getAPIKey() throws IOException {
        String key = null;
        Properties prop;
        FileReader reader;
        prop = new Properties();
        reader = new FileReader("src\\resources\\application.properties");
        prop.load(reader);
        key = prop.getProperty("apikey");
        return key;
    }


    public HashMap getSearchResults(String search) {
        String apikey = "e2f0126d33msh1bcc2d0fef09a0fp1e5165jsn03a911a71e43";
        HttpResponse<String> response = null;
        try {
            response = Unirest.get("https://imdb-internet-movie-database-unofficial.p.rapidapi.com/search/"+search)
                    .header("x-rapidapi-host", "imdb-internet-movie-database-unofficial.p.rapidapi.com")
                    .header("x-rapidapi-key", apikey)
                    .asString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        String res = response.getBody();
        HashMap<String,List<Map>> result = null;
        try {
            result = new ObjectMapper().readValue(res, HashMap.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;

    }

    public HashMap getFilmDetails(String id) throws Exception, IOException {
        String apikey = "e2f0126d33msh1bcc2d0fef09a0fp1e5165jsn03a911a71e43";
        HttpResponse<String> response = Unirest.get("https://imdb-internet-movie-database-unofficial.p.rapidapi.com/film/"+id)
                .header("x-rapidapi-host", "imdb-internet-movie-database-unofficial.p.rapidapi.com")
                .header("x-rapidapi-key", apikey)
                .asString();
        String res = response.getBody();
        HashMap<String,List<Map>> result =new ObjectMapper().readValue(res,HashMap.class);
        return result;
    }

    public static void main(String [] args){
        APIUtil apiUtil = new APIUtil();
        try {
            //Get Search Results
            HashMap searchMap = apiUtil.getSearchResults("inception");
            List<Map> titles = (List<Map>) searchMap.get("titles");
            for (Map m: titles
                 ) {
                m.get("title");
                m.get("image");
                m.get("id");

            }
            List<Map> companies = (List<Map>) searchMap.get("companies");
            for (Map m: companies
            ) {
                m.get("title");
                m.get("image");
                m.get("id");
            }

            List<Map> names = (List<Map>) searchMap.get("names");




            //Use the title id obtained from tiltes List into getFilmDetails
            HashMap filmMap = apiUtil.getFilmDetails("tt1375666");
            String id = (String) filmMap.get("id");
            String title = (String) filmMap.get("title");
            String year = (String) filmMap.get("year");
            String length = (String) filmMap.get("length");
            String rating = (String) filmMap.get("rating");
            String rating_votes = (String) filmMap.get("rating_votes");
            String posterLink = (String) filmMap.get("poster");
            String plot = (String) filmMap.get("plot");
            HashMap trailer = (HashMap) filmMap.get("trailer");
            String trailerLink = (String) trailer.get("link");

            List<Map>  cast = (List<Map>) filmMap.get("cast");
            for (Map m: cast
                 ) {
                m.get("actor");
                m.get("character");
            }
            System.out.println("Cast 1:"+cast.get(0));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
