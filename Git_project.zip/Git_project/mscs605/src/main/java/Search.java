
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/MovieSearchServlet")
public class Search extends HttpServlet {
    public Search(){
        super();
    }

    RequestDispatcher rd;

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        //response.setContentType("text/html");


        String movie = request.getParameter("movieName");

        HashMap result;

        result = getSearchResults(movie);



        List<Map> titles = (List<Map>) result.get("titles");
        request.setAttribute("moviesList", titles);

         rd = request.getRequestDispatcher("SearchResult.jsp");
         rd.forward(request,response);




    }

    public static HashMap getSearchResults(String search) {
        String apikey = "e2f0126d33msh1bcc2d0fef09a0fp1e5165jsn03a911a71e43";
        HttpResponse<String> response = null;
        try {
            response = Unirest.get("https://imdb-internet-movie-database-unofficial.p.rapidapi.com/search/"+search)
                    .header("x-rapidapi-host", "imdb-internet-movie-database-unofficial.p.rapidapi.com")
                    .header("x-rapidapi-key", apikey)
                    .asString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        String res = response.getBody();
        HashMap<String,List<Map>> result = null;
        try {
            result = new ObjectMapper().readValue(res, HashMap.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;

    }
}
